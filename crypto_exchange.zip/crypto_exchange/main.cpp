#include "domain/entities/Order.h"
#include "domain/entities/User.h"
#include "domain/services/OrderService.h"
#include "domain/services/UserService.h"
#include "infrastructure/models/OrderModel.h"
#include "infrastructure/models/UserModel.h"
#include "application/usecases/CreateOrder.h"
#include "application/usecases/CreateUser.h"
#include "infrastructure/utils/ThreadPool.h"
#include <iostream>

int main() {
    OrderModel orderModel;
    OrderService orderService(orderModel);
    CreateOrder createOrder(orderService);

    UserModel userModel;
    UserService userService(userModel);
    CreateUser createUser(userService);

    UserController userController(createUser);
    userController.createUser("1", "Alice", "alice@example.com");
    userController.createUser("2", "Bob", "bob@example.com");

    ThreadPool pool(4);

    pool.enqueue([&createOrder] {
        Order buyOrder("1", Order::BUY, 10.0, 50000.0, std::time(nullptr));
        createOrder.execute(buyOrder);
        std::cout << "Buy order created" << std::endl;
    });

    pool.enqueue([&createOrder] {
        Order sellOrder("2", Order::SELL, 5.0, 51000.0, std::time(nullptr));
        createOrder.execute(sellOrder);
        std::cout << "Sell order created" << std::endl;
    });

    std::this_thread::sleep_for(std::chrono::seconds(1));

    auto orders = orderModel.getAll();
    for (const auto& order : orders) {
        std::cout << "Order ID: " << order.getId()
                  << ", Type: " << (order.getType() == Order::BUY ? "BUY" : "SELL")
                  << ", Amount: " << order.getAmount()
                  << ", Price: " << order.getPrice()
                  << ", Timestamp: " << order.getTimestamp() << std::endl;
    }

    auto users = userModel.getAll();
    for (const auto& user : users) {
        std::cout << "User ID: " << user.getId()
                  << ", Name: " << user.getName()
                  << ", Email: " << user.getEmail() << std::endl;
    }

    return 0;
}