#ifndef USER_SERVICE_H
#define USER_SERVICE_H

#include "User.h"
#include "../repositories/UserRepository.h"

class UserService {
public:
    UserService(UserRepository& repository) : repository(repository) {}

    void createUser(const User& user) {
        repository.save(user);
    }

private:
    UserRepository& repository;
};

#endif // USER_SERVICE_H