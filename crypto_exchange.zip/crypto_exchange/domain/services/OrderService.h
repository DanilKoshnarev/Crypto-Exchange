#ifndef ORDER_SERVICE_H
#define ORDER_SERVICE_H

#include "Order.h"
#include "../repositories/OrderRepository.h"

class OrderService {
public:
    OrderService(OrderRepository& repository) : repository(repository) {}

    void createOrder(const Order& order) {
        repository.save(order);
    }

private:
    OrderRepository& repository;
};

#endif // ORDER_SERVICE_H