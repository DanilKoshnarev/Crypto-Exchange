#ifndef ORDER_H
#define ORDER_H

#include <string>
#include <ctime>

class Order {
public:
    enum OrderType { BUY, SELL };

    Order(std::string id, OrderType type, double amount, double price, std::time_t timestamp)
        : id(id), type(type), amount(amount), price(price), timestamp(timestamp) {}

    std::string getId() const { return id; }
    OrderType getType() const { return type; }
    double getAmount() const { return amount; }
    double getPrice() const { return price; }
    std::time_t getTimestamp() const { return timestamp; }

private:
    std::string id;
    OrderType type;
    double amount;
    double price;
    std::time_t timestamp;
};

#endif // ORDER_H