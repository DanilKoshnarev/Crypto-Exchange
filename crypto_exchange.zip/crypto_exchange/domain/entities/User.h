#ifndef USER_H
#define USER_H

#include <string>

class User {
public:
    User(std::string id, std::string name, std::string email)
        : id(id), name(name), email(email) {}

    std::string getId() const { return id; }
    std::string getName() const { return name; }
    std::string getEmail() const { return email; }

private:
    std::string id;
    std::string name;
    std::string email;
};

#endif // USER_H