#ifndef ORDER_REPOSITORY_H
#define ORDER_REPOSITORY_H

#include "Order.h"
#include <vector>

class OrderRepository {
public:
    virtual void save(const Order& order) = 0;
    virtual std::vector<Order> getAll() const = 0;
};

#endif // ORDER_REPOSITORY_H