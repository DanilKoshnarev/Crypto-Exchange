#ifndef USER_REPOSITORY_H
#define USER_REPOSITORY_H

#include "User.h"
#include <vector>

class UserRepository {
public:
    virtual void save(const User& user) = 0;
    virtual std::vector<User> getAll() const = 0;
};

#endif // USER_REPOSITORY_H