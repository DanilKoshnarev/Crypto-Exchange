#ifndef USER_MODEL_H
#define USER_MODEL_H

#include "../../domain/entities/User.h"
#include "../../domain/repositories/UserRepository.h"
#include <vector>

class UserModel : public UserRepository {
public:
    void save(const User& user) override {
        users.push_back(user);
    }

    std::vector<User> getAll() const override {
        return users;
    }

private:
    std::vector<User> users;
};

#endif // USER_MODEL_H