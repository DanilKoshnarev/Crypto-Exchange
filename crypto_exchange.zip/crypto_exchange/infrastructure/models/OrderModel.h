#ifndef ORDER_MODEL_H
#define ORDER_MODEL_H

#include "../../domain/entities/Order.h"
#include <vector>

class OrderModel : public OrderRepository {
public:
    void save(const Order& order) override {
        orders.push_back(order);
    }

    std::vector<Order> getAll() const override {
        return orders;
    }

private:
    std::vector<Order> orders;
};

#endif // ORDER_MODEL_H