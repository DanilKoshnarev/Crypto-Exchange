#ifndef USER_CONTROLLER_H
#define USER_CONTROLLER_H

#include "../../domain/entities/User.h"
#include "../../application/usecases/CreateUser.h"

class UserController {
public:
    UserController(CreateUser& createUser) : createUser(createUser) {}

    void createUser(const std::string& id, const std::string& name, const std::string& email) {
        User user(id, name, email);
        createUser.execute(user);
    }

private:
    CreateUser& createUser;
};

#endif // USER_CONTROLLER_H