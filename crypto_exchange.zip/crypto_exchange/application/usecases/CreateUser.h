#ifndef CREATE_USER_H
#define CREATE_USER_H

#include "../services/UserService.h"

class CreateUser {
public:
    CreateUser(UserService& service) : service(service) {}

    void execute(const User& user) {
        service.createUser(user);
    }

private:
    UserService& service;
};

#endif // CREATE_USER_H