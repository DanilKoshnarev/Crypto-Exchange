#ifndef CREATE_ORDER_H
#define CREATE_ORDER_H

#include "../services/OrderService.h"

class CreateOrder {
public:
    CreateOrder(OrderService& service) : service(service) {}

    void execute(const Order& order) {
        service.createOrder(order);
    }

private:
    OrderService& service;
};

#endif // CREATE_ORDER_H